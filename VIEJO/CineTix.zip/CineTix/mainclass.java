package CineTix;
import java.util.Scanner;
public class mainclass {


    public static void main(String[] args) {
    cine cd = new cine();
    int cont = 0;
    int vsala = 0;
   
    do {
        Scanner sc = new Scanner(System.in);
            System.out.println("\n===============================================\n\n\n\n\n Sala 1: Adulto: 5.00 Niño: 2.50\nSala 2: Adulto: 4.50 Niño: 2.00\nSala 3: Adulto: 7.00 Niño: 3.00");
            System.out.println("\nSala 4: Adulto: 5.50 Niño: 2.75\nSala 5: Adulto: 4.00 Niño: 1.75");
            
            
            System.out.println("\n\nIngrese la sala que elige el cliente");
            vsala=sc.nextInt();
        
        
        switch(vsala){
            case 1:
                cd.Sala1();
                cont = cont +1;
            break;
            case 2:
                cd.Sala2();
                cont = cont +1;
            break;
            
            case 3:
                cd.Sala3();
                cont = cont +1;
            break;
            
            case 4:
                cd.Sala4();
                cont = cont +1;
            break;
            
            case 5:
                cd.Sala5();
                cont = cont +1;
            
            break;
            
            default:
            System.out.println("Operacion Invalida");
            
            return;
        }
    }while (cont < 10);
        
    
   do{
    cd.totalVen();
    cd.VentasInfo();
    } while (cont>10);
    
       
    }

 

 
}





    

   

