package CineTix;
import java.util.ArrayList;
import java.util.Scanner;

public class cine {

private int sala;


//tipos de tickete//
private double kid;
private double adult;
private double free;

private double[] array_ticket = new double[0];

//Total recaudado//
private double total1;
private double total2;
private double total3;
private double total4;
private double total5;
private double[] array_sala = new double[0];

double adult1, adult2, adult3, adult4, adult5=0;
double kid1, kid2, kid3, kid4, kid5=0;
double totalA5, totalK5 =0;
double totalA2, totalK2 =0;
double totalA1, totalK1 =0;
double totalA3, totalK3 =0;
double totalA4, totalK4 =0;

public void SetArray_ticket(double[]array_ticket,int sala, double kid, double adult, double free){
this.array_ticket=array_ticket;
this.sala=sala;
this.kid=kid;
this.adult=adult;
this.free=free;

}

public void SetArray_sala(double total1,double total2,double total3, double total4, double total5){
    this.total1=total1;
    this.total2=total2;
    this.total3=total3;
    this.total4=total4;
    this.total5=total5;
}





public double[] getArray_ticket(){
    return array_ticket;
}

public double[] getArray_sala(){
    return array_sala;
}

public int getSala(){
    return sala;
}

public double getA(){
    return adult;
}

public double getB(){
    return kid;
}

public double getC(){
    return free;
}

public double get1(){
 return total1;
}

public double get2(){
    return total2;
   }public double get3(){
    return total3;
   }public double get4(){
    return total4;
   }public double get5(){
    return total5;
   }




    public void totalVen(){
        ArrayList<Double> array_sala = new ArrayList<Double>();
        array_sala.add(total1 + total2 + total3 + total4 +total5);
        for(int i = 0; i < array_sala.size(); i++){
            System.out.print("resultado: B/."+ array_sala.get(i)+ "dolares");
        }

    }


    

    public void Sala1(){
      
        double precioA = 5.00;
        double precioK = 2.50;
       
        int edad = 0;

        Scanner sc = new Scanner(System.in);

        System.out.println("\nIngrese la edad del cliente: ");
        edad = sc.nextInt();
        if (edad > 11){
            adult = adult +1;
        }
        else if (edad < 1.00){
            free = free +1;
        }
        else {
            kid = kid +1;
        }

        totalA1 = precioA * adult;
        totalK1= precioK * kid;
        total1 = totalA1+totalK1;

        adult1 = adult;
        kid1 = kid + free;
        sc.close();

    }

    public void Sala2(){
        
        double precioA = 4.50;
        double precioK = 2.00;
       
        int edad = 0;

        Scanner sc = new Scanner(System.in);

        System.out.println("\nIngrese la edad del cliente: ");
        
        edad = sc.nextInt();
        if (edad > 11){
            adult = adult +2;
        }
        else if (edad < 1){
            free = free +2;
        }
        else {
            kid = kid +2;
        }

        totalA2 = precioA * adult;
        totalK2= precioK * kid;
        total2 = totalA2+totalK2;

        adult2 = adult;
        kid2 = kid + free;
        

    }

    public void Sala3(){
        
        double precioA = 7.00;
        double precioK = 3.00;
        
        int edad = 0;

        Scanner sc = new Scanner(System.in);

        System.out.println("\nIngrese la edad del cliente: ");
        edad = sc.nextInt();
        if (edad > 11){
            adult = adult +3;
        }
        else if (edad < 1){
            free = free +3;
        }
        else {
            kid = kid +3;
        }

        totalA3 = precioA * adult;
        totalK3= precioK * kid;
        total3 = totalA3+totalK3;

        adult3 = adult;
        kid3 = kid + free;
        

    }
    public void Sala4(){
       
        double precioA = 5.50;
        double precioK = 2.75;
        
        int edad = 0;

        Scanner sc = new Scanner(System.in);

        System.out.println("\nIngrese la edad del cliente: ");
        edad = sc.nextInt();
        if (edad > 11){
            adult = adult +4;
        }
        else if (edad < 1){
            free = free +4;
        }
        else {
            kid = kid +4;
        }

        totalA4 = precioA * adult;
        totalK4= precioK * kid;
        total4 = totalA4+totalK4;

        adult4 = adult;
        kid4 = kid + free;
        

    }

    public void Sala5(){
        
        double precioA = 4.00;
        double precioK = 1.75;
        adult5= 0;
        kid5 =0;
        int edad = 0;

        Scanner sc = new Scanner(System.in);

        System.out.println("\nIngrese la edad del cliente: ");
        edad = sc.nextInt();
        if (edad > 11){
            adult = adult +5;
        }
        else if (edad < 1){
            free = free +5;
        }
        else {
            kid = kid +5;
        }

        totalA5 = precioA * adult;
        totalK5= precioK * kid;
        total5 = totalA5+totalK5;

        adult5 = adult;
        kid5 = kid + free;
        

    }



    public void VentasInfo(){
     
    
    System.out.println("\n\nEn la sala 1 se genera: $"+total1+". Dividido en: $"+ totalA1 +" de adultos y de "+totalK1+" de niños.");
    System.out.println("\nCantidad de ticketes, Adultos: "+adult1+" Niños: "+ kid1 );
    System.out.println("\n\nEn la sala 2 se genera: $"+total2+". Dividido en: $"+ totalA2 +" de adultos y de "+totalK2+" de niños.");
    System.out.println("\nCantidad de ticketes, Adultos: "+adult2+" Niños: "+kid2);
    System.out.println("\n\nEn la sala 3 se genera: $"+total3+". Dividido en: $"+ totalA3 +" de adultos y de "+totalK3+" de niños.");
    System.out.println("\nCantidad de ticketes, Adultos: "+adult3+" Niños: "+kid3);
    System.out.println("\n\nEn la sala 4 se genera: $"+total4+". Dividido en: $"+ totalA4 +" de adultos y de "+totalK4+" de niños.");
    System.out.println("\nCantidad de ticketes, Adultos: "+adult4+" Niños: "+kid4);
    System.out.println("\n\nEn la sala 5 se genera: $"+total5+". Dividido en: $"+ totalA5 +" de adultos y de "+totalK5+" de niños.");
    System.out.println("\nCantidad de ticketes, Adultos: "+adult5+" Niños: "+kid5);

    }
}
    
    
    




    
